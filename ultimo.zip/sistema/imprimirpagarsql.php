<?php
if (isset($_REQUEST["EQP_ID"])) {
    $ID = $_REQUEST["EQP_ID"];
}
try {
    require('fpdf/fpdf.php');
    $mysqli = new mysqli('localhost', 'root', '', 'oswa_inv');
    if ($mysqli->connect_errno) {
        echo "Failed to connect to MySQL: " . $mysqli->connect_error;
        exit();
    }
    $sql = "SELECT s.soc_nombre, c.cob_nombre, a.asg_saldo FROM asignar_cobros a, cobros c, socios s
    where 
    a.cob_id = c.cob_id and
    a.soc_id = s.soc_id and
    a.asg_estado = 1 and
    a.soc_id = " . $ID;
    $result = $mysqli->query($sql);
    $datos = mysqli_fetch_all($result, MYSQLI_ASSOC);
    $pdf = new FPDF();
    $contador = 0;
    $totalpagos = 0;
    foreach ($datos as $item => $row) {
        if ($contador == 0) {
            $pdf->AddPage();
            $pdf->SetFont('Arial', 'B', 14);
            $pdf->Cell(40, 6, '', 0, 0, 'C');
            $pdf->Cell(120, 6, 'COOPERATIVA ILUSTRE JUAN MONTALVO', 1, 0, 'C');
            $pdf->Ln(10);
            $pdf->SetFillColor(232, 232, 232);
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(90, 6, 'Nombre Socio', 1, 0, 'C', 1);
            $pdf->Cell(80, 6, utf8_decode('Cuenta'), 1, 0, 'C', 1);
            $pdf->Cell(20, 6, 'Valor', 1, 0, 'C', 1);
            $pdf->Ln(8);
            $pdf->SetFont('Arial', 'B', 8);
        }

        $tip_nombre = utf8_decode($row['soc_nombre']);
        $cob_nombre = utf8_decode($row['cob_nombre']);
        $agg_valor = $row['asg_saldo'];

        $totalpagos = $totalpagos + $agg_valor;

        $pdf->Cell(90, 8, $tip_nombre, 1, 0, 'L', 0);
        $pdf->Cell(80, 8, $cob_nombre, 1, 0, 'L', 0);
        $pdf->Cell(20, 8, $agg_valor, 1, 0, 'R', 0);
        $pdf->Ln();

        ++$contador;
        if ($contador == 60) {
            $contador = 0;
        }
    }


    $pdf->Cell(40, 6, 'Total Deuda : ' . $totalpagos, 1, 0, 'C', 1);

    $pdf->Output();
    mysqli_close($mysqli);
} catch (Exception $e) {
    echo 'Error : ', $e->getMessage(), "\n";
}
?>