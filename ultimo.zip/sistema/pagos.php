<?php
$page_title = 'Pago Gerencia';
require 'conexion.php';
require_once('includes/load.php');
page_require_level(1);
$groups = find_all_Tipos_Valores('tipos_valores');
//Update User basic info
if (isset($_POST['update'])) {

    if (isset($_REQUEST["cuenta"])) {
        $cuenta = $_REQUEST["cuenta"];
    }

    if (isset($_REQUEST["valor"])) {
        $valor = $_REQUEST["valor"];
    } else {
        $valor = 0;
    }

    $req_fields = array('cuenta', 'valor');
    validate_fields($req_fields);
    if (empty($errors)) {
        $cuenta = strtoupper(remove_junk($db->escape($cuenta)));
        $valor = strtoupper(remove_junk($db->escape($valor)));
        $sql = "insert into asignar_gastos (agg_valor, agg_fecha, tip_id) values ($valor, now(), $cuenta);";
        $result = $db->query($sql);
        if ($result && $db->affected_rows() === 1) {
            $session->msg('s', "Pago realizado con éxito ");
            redirect('pagos.php', false);
        } else {
            $session->msg('d', ' Lo siento no se realizo el pago.');
            redirect('pagos.php', false);
        }
    } else {
        $session->msg("d", $errors);
        redirect('pagos.php', false);
    }
}
?>






<?php include_once('layouts/header.php'); ?>
<div class="row">
    <div class="col-md-12"> <?php echo display_msg($msg); ?> </div>
    <div class="col-md-6">
        <div class="panel panel-default">



            <div class="panel-heading">
                <strong>
                    <span class="glyphicon glyphicon-th"></span>
                    Pago Cuentas Gerencia
                </strong>
            </div>
            <div class="panel-body">
                <form method="post" action="" class="clearfix">
                    <div class="form-group">
                        <label for="level">Cuenta</label>
                        <select class="form-control" name="cuenta">
                            <?php foreach ($groups as $group): ?>
                                <option <?php echo $group['tip_id']; ?> value="<?php echo $group['tip_id']; ?>"><?php echo ucwords($group['tip_nombre']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>


                    <div class="form-group">
                        <label for="username" class="control-label">Valor</label>
                        <input type="text" class="form-control" name="valor" >
                    </div>

                    <div class="form-group clearfix">
                        <button type="submit" name="update" class="btn btn-info">Pago Gerencia</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>
<?php include_once('layouts/footer.php'); ?>