<?php
try {
    require('fpdf/fpdf.php');
    $mysqli = new mysqli('localhost', 'root', '', 'oswa_inv');
    if ($mysqli->connect_errno) {
        echo "Failed to connect to MySQL: " . $mysqli->connect_error;
        exit();
    }
    $sql = "select agg_valor, tip_nombre, agg_fecha from asignar_gastos a, tipos_valores t where a.tip_id = t.tip_id order by agg_fecha;";
    $result = $mysqli->query($sql);
    $datos = mysqli_fetch_all($result, MYSQLI_ASSOC);
    $pdf = new FPDF();

    $contador = 0;
    $totalpagos = 0;
    foreach ($datos as $item => $row) {
        if ($contador == 0) {
            $pdf->AddPage();
            $pdf->SetFont('Arial', 'B', 14);
            $pdf->Cell(40, 6, '', 0, 0, 'C');
            $pdf->Cell(120, 6, 'COOPERATIVA ILUSTRE JUAN MONTALVO', 1, 0, 'C');
            $pdf->Ln(10);
            $pdf->SetFillColor(232, 232, 232);
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(120, 6, 'Nombre Cuenta', 1, 0, 'C', 1);
            $pdf->Cell(30, 6, utf8_decode('Fecha'), 1, 0, 'C', 1);
            $pdf->Cell(40, 6, 'Valor', 1, 0, 'C', 1);
            $pdf->Ln(8);
            $pdf->SetFont('Arial', 'B', 8);
        }

        $tip_nombre = $row['tip_nombre'];
        $agg_fecha = $row['agg_fecha'];
        $agg_valor = $row['agg_valor'];

        $totalpagos = $totalpagos + $agg_valor;

        $pdf->Cell(120, 8, $tip_nombre, 1, 0, 'L', 0);
        $pdf->Cell(30, 8, $agg_fecha, 1, 0, 'C', 0);
        $pdf->Cell(40, 8, $agg_valor, 1, 0, 'R', 0);
        $pdf->Ln();

        ++$contador;
        if ($contador == 60) {
            $contador = 0;
        }
    }


    $pdf->Cell(40, 6, 'Total Pagos : ' . $totalpagos, 1, 0, 'C', 1);

    $pdf->Output();
    mysqli_close($mysqli);
} catch (Exception $e) {
    echo 'Error : ', $e->getMessage(), "\n";
}
?>
