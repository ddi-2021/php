<?php
if (isset($_REQUEST["EQP_ID"])) {
    $ID = $_REQUEST["EQP_ID"];
}
try {
    require('fpdf/fpdf.php');
    $mysqli = new mysqli('localhost', 'root', '', 'oswa_inv');
    if ($mysqli->connect_errno) {
        echo "Failed to connect to MySQL: " . $mysqli->connect_error;
        exit();
    }
    $sql = "SELECT * FROM recibos r
            JOIN asignar_cobros a ON r.asg_id = a.asg_id
            JOIN cobros c ON c.cob_id = a.cob_id 
            WHERE 
            r.rec_id = " . $ID ." LIMIT 1" ;
    
    $result = $mysqli->query($sql);
    $datos = mysqli_fetch_all($result, MYSQLI_ASSOC);
    $pdf = new FPDF();
    $contador = 0;
    $totalpagos = 0;
    foreach ($datos as $item => $row) {
        $rec_id = utf8_decode($row['rec_id']);
        $cob_nombre = utf8_decode($row['cob_nombre']);
        $rec_valor = $row['rec_valor'];
        $rec_fecha = $row['rec_fecha'];
        
        if ($contador == 0) {
            $pdf->AddPage();
            $pdf->SetFont('Arial', 'B', 14);
            $pdf->Cell(40, 6, '', 0, 0, 'C');
            $pdf->Cell(120, 6, 'COOPERATIVA ILUSTRE JUAN MONTALVO', 1, 0, 'C');
            $pdf->Ln(10);
            $pdf->Cell(190, 6, 'RECIBO DE PAGO', 0, 0, 'C');
            $pdf->Ln(10);
            
            
            $pdf->SetFont('Arial', '', 10);
            $pdf->Cell(110, 10, 'Recibo : '.$rec_id, 0, 0, 'L', 0);
            $pdf->Ln(10);
            $pdf->Cell(110, 10, 'Cuenta : '.$cob_nombre, 0, 0, 'L', 0);
            $pdf->Ln(10);
            $pdf->Cell(110, 10, 'Valor : $'.$rec_valor, 0, 0, 'L', 0);
            $pdf->Ln(10);
            $pdf->Cell(110, 10, 'Fecha : '.$rec_fecha, 0, 0, 'L', 0);
            $pdf->Ln(8);
            $pdf->SetFont('Arial', 'B', 8);
        }

            $pdf->Cell(190, 10, '__________________', 0, 0, 'C', 0);
            $pdf->Ln(8);
            $pdf->Cell(190, 10, '        Firma     ', 0, 0, 'C', 0);
            $pdf->Ln(8);

        
        $pdf->Ln();

        ++$contador;
        if ($contador == 30) {
            $contador = 0;
        }
    }

    $pdf->Output();
    mysqli_close($mysqli);
} catch (Exception $e) {
    echo 'Error : ', $e->getMessage(), "\n";
}
?>