<?php
$page_title = 'Cobro Socios';
require 'conexion.php';
require_once('includes/load.php');
// Checkin What level user has permission to view this page
page_require_level(1);
if (isset($_REQUEST["EQP_ID"])) {
    $ID = $_REQUEST["EQP_ID"];
}

$query = "SELECT * FROM asignar_cobros a, cobros c, socios s
where 
a.cob_id = c.cob_id and
a.soc_id = s.soc_id and
a.asg_estado = 1 and
a.asg_id = " . $ID;
$resultado = $mysqli->query($query);

if ($row = $resultado->fetch_assoc()) {
    $soc_nombre = $row['soc_nombre'];
    $cob_nombre = $row['cob_nombre'];
    $asg_saldo = $row['asg_saldo'];
    $asg_total = $row['asg_total'];
    $asg_valor = $row['asg_valor'];
}

//Update User basic info
if (isset($_POST['update'])) {


    if (isset($_REQUEST["valor"])) {
        $valor = $_REQUEST["valor"];
    } else {
        $valor = 0;
    }
    $saldopago = $asg_saldo - $valor;

    if ($saldopago == 0) {
        $estado = 0;
    } else {
        $estado = 1;
    }


    if (empty($errors)) {
        $id = (int) $ID;
        $sql = "UPDATE asignar_cobros SET asg_saldo = $saldopago, asg_valor = $valor , asg_estado= $estado WHERE asg_id=". $ID;
        $result = $db->query($sql);
        if ($result && $db->affected_rows() === 1) {
            $session->msg('s', "Cuenta actualizada ");
            // inserta en la tabla de recibos para la impresión
            $queryrecibo = "INSERT INTO RECIBOS (cob_id, rec_valor, rec_fecha) VALUES ($ID, $valor, NOW());";
            $resultado = $db->query($queryrecibo);
            if ($resultado && $db->affected_rows() === 1) {
                $session->msg('s', "Recibo guardado en forma satisfactoria ");
            }
            else 
            {
                $session->msg('s', "El recibo no se guardo ");
            }
                        
            redirect('busqueda_cont.php?id=' . (int) $e_user['id'], false);
        } else {
            $session->msg('d', ' Lo siento no se actualizó los datos.');
            redirect('pagar.php?id=' . (int) $ID, false);
        }
    } else {
        $session->msg("d", $errors);
        redirect('busqueda_cont.php?id=' . (int) $ID, false);
    }
}
?>






<?php include_once('layouts/header.php'); ?>
<div class="row">
    <div class="col-md-12"> <?php echo display_msg($msg); ?> </div>
    <div class="col-md-6">
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong>
                    <span class="glyphicon glyphicon-th"></span>
                    Pago Socio : <?php echo remove_junk(ucwords($soc_nombre)); ?>
                </strong>
            </div>
            <div class="panel-body">
                <form method="post" action="" class="clearfix">
                    <div class="form-group">
                        <label for="name" class="control-label">CUENTA : </label>
                        <label for="name" class="control-label"><?php echo remove_junk(ucwords($cob_nombre)); ?></label>
                    </div>
                    <div class="form-group">
                        <label for="username" class="control-label">Valor</label>
                        <input type="text" class="form-control" name="valor" value="<?php echo remove_junk(ucwords($asg_saldo)); ?>">
                    </div>

                    <div class="form-group clearfix">
                        <button type="submit" name="update" class="btn btn-info">Pagar Socio</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>
<?php include_once('layouts/footer.php'); ?>