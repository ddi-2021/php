<?php
$page_title = 'Agregar Cobros';
require_once('includes/load.php');
// Checkin What level user has permission to view this page
page_require_level(1);
$groups = find_Tipo_Valores('tipos_valores');
?>
<?php
if (isset($_POST['add_cobros'])) {

    $req_fields = array('name', 'valor', 'fechainicio', 'fechafin', 'level', 'tipo');
    validate_fields($req_fields);

    if (empty($errors)) {
        $name = remove_junk($db->escape($_POST['name']));
        $valor = remove_junk($db->escape($_POST['valor']));
        $fechainicio = remove_junk($db->escape($_POST['fechainicio']));
        $fechafin = remove_junk($db->escape($_POST['fechafin']));
        $level = (int) $db->escape($_POST['level']);
        $tipo = $db->escape($_POST['tipo']);
        
        $query = "INSERT INTO cobros (";
        $query .= "tip_id, cob_nombre, cob_valor, cob_fecha_inicio, cob_fecha_fin, cob_tipo";
        $query .= ") VALUES (";
        $query .= "'{$level}','{$name}', '{$valor}', '{$fechainicio}', '{$fechafin}','{$tipo}'";
        $query .= ")";
       
        if ($db->query($query)) {
            //sucess
            $session->msg('s', " El Cobro se ha generado en forma exitosa ");
            redirect('add_cobros.php', false);
        } else {
            //failed
            $session->msg('d', ' No se pudo crear el Cobro.');
            redirect('add_cobros.php', false);
        }
    } else {
        $session->msg("d", $errors);
        redirect('add_cobros.php', false);
    }
}
?>
<?php include_once('layouts/header.php'); ?>
<?php echo display_msg($msg); ?>
<div class="row">
    <div class="panel panel-default">
        <div class="panel-heading">
            <strong>
                <span class="glyphicon glyphicon-th"></span>
                <span>Agregar Cobro</span>
            </strong>
        </div>
        <div class="panel-body">
            <div class="col-md-6">
                <form method="post" action="add_cobros.php">
                    <div class="form-group">
                        <label for="name">Nombre Cuenta</label>
                        <input type="text" class="form-control" name="name" placeholder="Nombre Cuenta" required>
                    </div>
                    <div class="form-group">
                        <label for="Valor">Valor</label>
                        <input type="text" class="form-control" name="valor" placeholder="Valor" required>
                    </div>
                    <div class="form-group">
                        <label for="fechainicio">Fecha Inicio</label>
                        <input type="date" class="form-control" name ="fechainicio">
                    </div>
                    <div class="form-group">
                        <label for="fechainicio">Fecha Fin</label>
                        <input type="date" class="form-control" name ="fechafin">
                    </div>              
                    <div class="form-group">
                        <label for="level">Tipo</label>
                        <select class="form-control" name="level">
                            <?php foreach ($groups as $group): ?>
                                <option value="<?php echo $group['tip_id']; ?>"><?php echo utf8_decode(ucwords($group['tip_nombre'])); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <div class="row">   
                            <div class="col-md-12">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="glyphicon glyphicon-tags"></i>
                                    </span>
                                    <select class="form-control" name="tipo" requerid>
                                        <option value=1>INDIVIDUAL</option>
                                        <option value=0>PARA TODOS</option>
                                    </select>
                                </div>
                            </div>

                        </div>
                    </div> 



                    <div class="form-group clearfix">
                        <button type="submit" name="add_cobros" class="btn btn-primary">Guardar Cuenta</button>
                    </div>
                </form>
            </div>

        </div>

    </div>
</div>

<?php include_once('layouts/footer.php'); ?>
