-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 16-03-2022 a las 16:46:07
-- Versión del servidor: 5.5.24-log
-- Versión de PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `oswa_inv`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignar_cobros`
--

DROP TABLE IF EXISTS `asignar_cobros`;
CREATE TABLE IF NOT EXISTS `asignar_cobros` (
  `asg_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soc_id` int(11) NOT NULL,
  `cob_id` int(11) NOT NULL,
  `asg_valor` float NOT NULL,
  `asg_saldo` float NOT NULL,
  `asg_total` float NOT NULL,
  `asg_fecha` tinyint(11) NOT NULL,
  `asg_transaccion` date NOT NULL,
  `asg_estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`asg_id`),
  UNIQUE KEY `asg_id` (`asg_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `asignar_cobros`
--

INSERT INTO `asignar_cobros` (`asg_id`, `soc_id`, `cob_id`, `asg_valor`, `asg_saldo`, `asg_total`, `asg_fecha`, `asg_transaccion`, `asg_estado`) VALUES
(1, 1, 1, 0, 30, 30, 127, '0000-00-00', 1),
(2, 1, 2, 0, 30, 30, 127, '0000-00-00', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignar_gastos`
--

DROP TABLE IF EXISTS `asignar_gastos`;
CREATE TABLE IF NOT EXISTS `asignar_gastos` (
  `agg_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `agg_valor` float NOT NULL,
  `agg_fecha` date NOT NULL,
  `agg_estado` tinyint(1) NOT NULL DEFAULT '1',
  `tip_id` int(11) NOT NULL,
  PRIMARY KEY (`agg_id`),
  UNIQUE KEY `agg_id` (`agg_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `asignar_gastos`
--

INSERT INTO `asignar_gastos` (`agg_id`, `agg_valor`, `agg_fecha`, `agg_estado`, `tip_id`) VALUES
(1, 100, '2022-03-14', 1, 5),
(2, 7.85, '2022-03-14', 1, 5),
(3, 7.25, '2022-03-14', 1, 3),
(4, 11.25, '2022-03-14', 1, 4),
(5, 7.25, '2022-03-16', 1, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `autos`
--

DROP TABLE IF EXISTS `autos`;
CREATE TABLE IF NOT EXISTS `autos` (
  `aut_id` int(11) NOT NULL AUTO_INCREMENT,
  `soc_id` bigint(20) NOT NULL,
  `aut_placa` varchar(10) NOT NULL,
  `aut_numero` varchar(4) NOT NULL,
  `aut_permiso` varchar(10) NOT NULL,
  `aut_estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`aut_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `autos`
--

INSERT INTO `autos` (`aut_id`, `soc_id`, `aut_placa`, `aut_numero`, `aut_permiso`, `aut_estado`) VALUES
(1, 6, 'PLACA222', '26', 'PERMISO222', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Repuestos'),
(2, 'victor fredy martinez albuja');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cobros`
--

DROP TABLE IF EXISTS `cobros`;
CREATE TABLE IF NOT EXISTS `cobros` (
  `cob_id` bigint(20) NOT NULL,
  `tip_id` int(11) NOT NULL,
  `cob_nombre` varchar(150) NOT NULL,
  `cob_valor` float NOT NULL,
  `cob_fecha_inicio` date NOT NULL,
  `cob_fecha_fin` date NOT NULL,
  `cob_estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cob_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cobros`
--

INSERT INTO `cobros` (`cob_id`, `tip_id`, `cob_nombre`, `cob_valor`, `cob_fecha_inicio`, `cob_fecha_fin`, `cob_estado`) VALUES
(0, 1, 'CUOTA ENERO 2022', 30, '2022-01-01', '2022-01-30', 1),
(1, 1, 'CUOTA FEBRERO 2022', 30, '2022-02-01', '2022-02-28', 1),
(2, 1, 'CUOTA MARZO 2022', 30, '2022-03-01', '2022-03-31', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `colaboradores`
--

DROP TABLE IF EXISTS `colaboradores`;
CREATE TABLE IF NOT EXISTS `colaboradores` (
  `col_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `col_nombre` varchar(150) NOT NULL,
  `col_direccion1` varchar(150) NOT NULL,
  `col_celular` varchar(10) NOT NULL,
  `col_telefono` varchar(10) NOT NULL,
  `col_direccion2` varchar(150) NOT NULL,
  `col_ubicacion` varchar(150) NOT NULL,
  `col_referencia` varchar(150) NOT NULL,
  `col_estado` tinyint(1) NOT NULL DEFAULT '1',
  `col_cedula` varchar(10) NOT NULL,
  PRIMARY KEY (`col_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `colaboradores`
--

INSERT INTO `colaboradores` (`col_id`, `col_nombre`, `col_direccion1`, `col_celular`, `col_telefono`, `col_direccion2`, `col_ubicacion`, `col_referencia`, `col_estado`, `col_cedula`) VALUES
(1, 'JUAN DE DIOS NARVAEZ', 'QUITO', '0998873021', '0998873021', 'QUITO', 'QUITO', 'QUITO', 1, '1706876727'),
(3, 'JUAN DE DIOS NARVAEZ', 'QUITO45', '0998873021', '0998873021', 'QUITO45', 'QUITO45', 'QUITO45', 1, '1706876727');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `coopertativa`
--

DROP TABLE IF EXISTS `coopertativa`;
CREATE TABLE IF NOT EXISTS `coopertativa` (
  `coo_id` int(11) NOT NULL,
  `coo_nombre` varchar(150) NOT NULL,
  `coo_numero` varchar(4) NOT NULL,
  `coo_direccion` varchar(150) NOT NULL,
  `coo_telefono` varchar(10) NOT NULL,
  `coo_resolucion` varchar(10) NOT NULL,
  `coo_estado` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `coopertativa`
--

INSERT INTO `coopertativa` (`coo_id`, `coo_nombre`, `coo_numero`, `coo_direccion`, `coo_telefono`, `coo_resolucion`, `coo_estado`) VALUES
(1, 'COOPERATIVA ILUSTRE JUAN MONTALVO', '153', 'URB. MONJAS ALTAS', '', '', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_recibo`
--

DROP TABLE IF EXISTS `detalle_recibo`;
CREATE TABLE IF NOT EXISTS `detalle_recibo` (
  `det_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cob_id` int(11) NOT NULL,
  `det_valor` float NOT NULL,
  `rec_id` int(11) NOT NULL,
  `det_fecha` date NOT NULL,
  `det_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`det_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `media`
--

DROP TABLE IF EXISTS `media`;
CREATE TABLE IF NOT EXISTS `media` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `media`
--

INSERT INTO `media` (`id`, `file_name`, `file_type`) VALUES
(1, 'filter.jpg', 'image/jpeg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `quantity` varchar(50) DEFAULT NULL,
  `buy_price` decimal(25,2) DEFAULT NULL,
  `sale_price` decimal(25,2) NOT NULL,
  `categorie_id` int(11) unsigned NOT NULL,
  `media_id` int(11) DEFAULT '0',
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recibos`
--

DROP TABLE IF EXISTS `recibos`;
CREATE TABLE IF NOT EXISTS `recibos` (
  `rec_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL COMMENT 'id del usuario programa',
  `rec_valor` float NOT NULL,
  `rec_fecha` float NOT NULL,
  `rec_observacion` varchar(150) NOT NULL,
  `rec_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`rec_id`),
  UNIQUE KEY `rec_id` (`rec_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sales`
--

DROP TABLE IF EXISTS `sales`;
CREATE TABLE IF NOT EXISTS `sales` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) unsigned NOT NULL,
  `qty` int(11) NOT NULL,
  `price` decimal(25,2) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `socios`
--

DROP TABLE IF EXISTS `socios`;
CREATE TABLE IF NOT EXISTS `socios` (
  `soc_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id socio coop',
  `soc_cedula` varchar(10) NOT NULL,
  `coo_id` int(11) NOT NULL,
  `soc_nombre` varchar(150) NOT NULL,
  `soc_direccion1` varchar(150) NOT NULL,
  `soc_celular` varchar(10) NOT NULL,
  `soc_telefono` varchar(10) NOT NULL,
  `soc_direccion2` varchar(150) NOT NULL,
  `soc_ubicacion` varchar(150) NOT NULL,
  `soc_referencia` varchar(150) NOT NULL,
  `soc_estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`soc_id`),
  UNIQUE KEY `soc_id` (`soc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `socios`
--

INSERT INTO `socios` (`soc_id`, `soc_cedula`, `coo_id`, `soc_nombre`, `soc_direccion1`, `soc_celular`, `soc_telefono`, `soc_direccion2`, `soc_ubicacion`, `soc_referencia`, `soc_estado`) VALUES
(1, '', 1, 'MARTINEZ ALBUJA VICTOR FREDY GUSTAVO', 'ISABEL DE SANTIAGO', '0998873021', '0998873021', 'TORRES PONCEANO Y MARIA ONTANEDA', 'PONCEANO BAJO', 'CERCA DEL ESTADIO DE LA LIGA', 1),
(6, '', 1, 'WASHINGTON MARTINEZ', 'SANTA RITA', '0998873021', '0998873021', 'STA RITA', 'ESTADIO DEL AUCAS', 'ESTADIO DEL AUCAS', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `socio_colaborador`
--

DROP TABLE IF EXISTS `socio_colaborador`;
CREATE TABLE IF NOT EXISTS `socio_colaborador` (
  `soc_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `col_id` bigint(20) NOT NULL,
  `scol_estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`soc_id`),
  UNIQUE KEY `soc_id` (`soc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_valores`
--

DROP TABLE IF EXISTS `tipos_valores`;
CREATE TABLE IF NOT EXISTS `tipos_valores` (
  `tip_id` int(11) NOT NULL AUTO_INCREMENT,
  `tip_nombre` varchar(150) NOT NULL,
  `tip_tipo` tinyint(4) NOT NULL COMMENT '1 Cobros 2 Pagos',
  `tip_estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`tip_id`),
  UNIQUE KEY `tip_id` (`tip_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `tipos_valores`
--

INSERT INTO `tipos_valores` (`tip_id`, `tip_nombre`, `tip_tipo`, `tip_estado`) VALUES
(1, 'COBROS MENSUALES SOCIOS', 1, 1),
(2, 'COBROS MAQUINAS SOCIOS', 1, 1),
(3, 'LUZ', 2, 1),
(4, 'AGUA', 2, 1),
(5, 'TELEFONO', 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_level` int(11) NOT NULL,
  `image` varchar(255) DEFAULT 'no_image.jpg',
  `status` int(1) NOT NULL DEFAULT '1',
  `last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `user_level`, `image`, `status`, `last_login`) VALUES
(1, 'Admin Users', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 1, 'pzg9wa7o1.jpg', 1, '2022-01-15 22:20:31'),
(2, 'Special User', 'special', 'ba36b97a41e7faf742ab09bf88405ac04f99599a', 2, 'no_image.jpg', 1, '2017-06-16 07:11:26'),
(3, 'Default User', 'user', '12dea96fec20593566ab75692c9949596833adc9', 3, 'no_image.jpg', 1, '2017-06-16 07:11:03'),
(10, 'victor martinez', 'vicman', 'f72550bfb9e3388e289af85a8904d32df9ae7d18', 1, 'pzg9wa7o1.jpg', 1, '2022-03-16 15:27:24');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
CREATE TABLE IF NOT EXISTS `user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(150) NOT NULL,
  `group_level` int(11) NOT NULL,
  `group_status` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `user_groups`
--

INSERT INTO `user_groups` (`id`, `group_name`, `group_level`, `group_status`) VALUES
(1, 'Admin', 1, 1),
(2, 'Gerencia', 2, 1),
(3, 'User', 3, 1),
(4, 'secretario', 4, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
