<?php
$page_title = 'Coop. Ilustre Juan Montalvo';
require_once('includes/load.php');
page_require_level(1);
?>
<?php
$c_cobros = sumacobros('asignar_cobros');
$c_gastos = sumagastos('asignar_gastos');
$c_usuarios = count_by_id('users');

$Cobro = round($c_cobros['total'], 2);
$Gasto = round($c_gastos['total'], 2);
$Usuario = $c_usuarios['total'];
$total = $Cobro - $Gasto;
?>
<?php include_once('layouts/header.php'); ?>

<div class="row">
    <div class="col-md-6">
        <?php echo display_msg($msg); ?>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="panel panel-box clearfix">
            <div class="panel-icon pull-left bg-green">
                <i class="glyphicon glyphicon-user"></i>
            </div>
            <div class="panel-value pull-right">
                <h2 class="margin-top"> <?php echo $Usuario; ?> </h2>
                <p class="text-muted">Usuarios</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="panel panel-box clearfix">
            <div class="panel-icon pull-left bg-red">
                <i class="glyphicon glyphicon-list"></i>
            </div>
            <div class="panel-value pull-right">
                <h2 class="margin-top"> <?php echo $Cobro; ?> </h2>
                <p class="text-muted">Total Cobros</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="panel panel-box clearfix">
            <div class="panel-icon pull-left bg-blue">
                <i class="glyphicon glyphicon-shopping-cart"></i>
            </div>
            <div class="panel-value pull-right">
                <h2 class="margin-top"> <?php echo $Gasto; ?> </h2>
                <p class="text-muted">Total Gastos</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="panel panel-box clearfix">
            <div class="panel-icon pull-left bg-yellow">
                <i class="glyphicon glyphicon-usd"></i>
            </div>
            <div class="panel-value pull-right">
                <h2 class="margin-top"> <?php echo $total; ?></h2>
                <p class="text-muted">Total</p>
            </div>
        </div>
    </div>
</div>

</div>
<div class="row">
</div>
<?php include_once('layouts/footer.php'); ?>