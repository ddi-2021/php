<?php
  $page_title = 'Agregar Colaborador';
  require_once('includes/load.php');
  page_require_level(1);
?>
<?php
  if(isset($_POST['add_socio'])){

   $req_fields = array('nombre',  'cedula', 'direccion','celular','telefono', 'direccion2', 'ubicacion', 'referencia' );
   validate_fields($req_fields);

   if(empty($errors)){
       $nombre   = strtoupper(remove_junk($db->escape($_POST['nombre'])));
       $cedula   = strtoupper(remove_junk($db->escape($_POST['cedula'])));
       $direccion   = strtoupper(remove_junk($db->escape($_POST['direccion'])));
       $celular   = strtoupper(remove_junk($db->escape($_POST['celular'])));
       $telefono   = strtoupper(remove_junk($db->escape($_POST['telefono'])));
       $direccion2   = strtoupper(remove_junk($db->escape($_POST['direccion2'])));
       $ubicacion   = strtoupper(remove_junk($db->escape($_POST['ubicacion'])));
       $referencia   = strtoupper(remove_junk($db->escape($_POST['referencia'])));

        $query = "INSERT INTO colaboradores (";
        $query .="col_nombre, col_cedula, col_direccion1, col_celular, col_telefono, col_direccion2, col_ubicacion, col_referencia";
        $query .=") VALUES (";
        $query .="'{$nombre}', '{$cedula}', '{$direccion}', '{$celular}', '{$telefono}','{$direccion2}', '{$ubicacion}', '{$referencia}'";
        $query .=")";

       if($db->query($query)){
          //sucess
          $session->msg('s'," El Colaborador se ha creado satisfactoriamente");
          redirect('add_colaboradores.php', false);
        } else {
          //failed
          $session->msg('d',' No se pudo crear el Colaborador.');
          redirect('add_colaboradores.php', false);
        }
   } else {
     $session->msg("d", $errors);
      redirect('add_colaboradores.php',false);
   }
 }
?>
<?php include_once('layouts/header.php'); ?>
  <?php echo display_msg($msg); ?>
  <div class="row">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Agregar Colaborador</span>
       </strong>
      </div>
      <div class="panel-body">
        <div class="col-md-6">
          <form method="post" action="add_colaboradores.php">
            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" class="form-control" name="nombre" placeholder="Nombres completos del Socio" required>
            </div>

            <div class="form-group">
                <label for="cedula">Cédula</label>
                <input type="text" class="form-control" name="cedula" placeholder="Cédula" required>
            </div>


            <div class="form-group">
                <label for="direccion">Dirección</label>
                <input type="text" class="form-control" name="direccion" placeholder="Dirección del Colaborador">
            </div>
            <div class="form-group">
                <label for="celular">Celular</label>
                <input type="text" class="form-control" name ="celular"  placeholder="Celular">
            </div>
            <div class="form-group">
                <label for="telefono">Teléfono</label>
                <input type="text" class="form-control" name ="telefono"  placeholder="Teléfono">
            </div>

            <div class="form-group">
                <label for="direccion">Dirección 2</label>
                <input type="text" class="form-control" name ="direccion2"  placeholder="Dirección alternativa">
            </div>

            <div class="form-group">
                <label for="ubicacion">Ubicación</label>
                <input type="text" class="form-control" name ="ubicacion"  placeholder="Ubicación del Colaborador">
            </div>


            <div class="form-group">
                <label for="referencia">Referencia</label>
                <input type="text" class="form-control" name ="referencia"  placeholder="Referencia de de donde vive">
            </div>


            <div class="form-group clearfix">
              <button type="submit" name="add_socio" class="btn btn-primary">Guardar Colaborador</button>
            </div>
        </form>
        </div>

      </div>

    </div>
  </div>

<?php include_once('layouts/footer.php'); ?>
