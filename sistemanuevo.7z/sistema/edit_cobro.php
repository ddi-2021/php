<?php
$page_title = 'Editar Cobro';
require_once('includes/load.php');
// Checkin What level user has permission to view this page
page_require_level(1);
?>
<?php
//Display all catgories.
$categorie = find_by_Cobros('cobros', (int) $_GET['id']);
$id = $_GET['id'];
if (!$categorie) {
    $session->msg("d", "No se ecuentra la ID.");
    redirect('cobrosadm.php');
}
?>

<?php
if (isset($_POST['edit_cat'])) {
    $cat_name = strtoupper(remove_junk($db->escape($_POST['categorie-name'])));
    $valor = remove_junk($db->escape($_POST['valor']));
    $tipo = remove_junk($db->escape($_POST['tipo']));

    if (empty($errors)) {
        $sql = "UPDATE cobros SET cob_nombre='{$cat_name}', cob_valor='{$valor}' , cob_tipo='{$tipo}'";
        $sql .= " WHERE cob_id=".$id;
        $result = $db->query($sql);
        if ($result && $db->affected_rows() === 1) {
            $session->msg("s", "Cobro actualizada con éxito.");
            redirect('cobrosadm.php', false);
        } else {
            $session->msg("d", "Lo siento, actualización falló.");
            redirect('cobrosadm.php', false);
        }
    } else {
        $session->msg("d", $errors);
        redirect('cobrosadm.php', false);
    }
}
?>
<?php include_once('layouts/header.php'); ?>

<div class="row">
    <div class="col-md-12">
        <?php echo display_msg($msg); ?>
    </div>
    <div class="col-md-5">
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong>
                    <span class="glyphicon glyphicon-th"></span>
                    <span>Editando <?php echo remove_junk(ucfirst($categorie['cob_nombre'])); ?></span>
                </strong>
            </div>
            <div class="panel-body">
                <form method="post" action="edit_cobro.php?id=<?php echo (int) $categorie['cob_id']; ?>">
                    <div class="form-group">
                        <input type="text" class="form-control" name="categorie-name" value="<?php echo remove_junk(ucfirst($categorie['cob_nombre'])); ?>">
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control" name="valor" value="<?php echo remove_junk(ucfirst($categorie['cob_valor'])); ?>">
                    </div>

                    <div class="form-group">
                        <div class="row">   
                            <div class="col-md-12">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="glyphicon glyphicon-tags"></i>
                                    </span>
                                    <select class="form-control" name="tipo" requerid>
                                        <option value=1>INDIVIDUAL</option>
                                        <option value=0>PARA TODOS</option>
                                    </select>
                                </div>
                            </div>

                        </div>
                    </div> 
                    <button type="submit" name="edit_cat" class="btn btn-primary">Actualizar Cobro</button>
                </form>
            </div>
        </div>
    </div>
</div>



<?php include_once('layouts/footer.php'); ?>
