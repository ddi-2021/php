<?php
error_reporting(0);
$page_title = 'Bùsqueda por Socio';
require_once('includes/load.php');
page_require_level(3);
include_once('layouts/header.php');
?>
<div class="row">
<div class="col-md-6">
<div class="panel">
<div class="panel-body">
<form class="clearfix" method="post" action="">
  <div class="form-group">
  <div class="panel panel-default">
  <div class="panel-heading clearfix">
  <strong>
    <span class="glyphicon glyphicon-th"></span>
    <span>BÚSQUEDA PAGOS SOCIOS</span>
  </strong>
  </div>
  </div>
  <div class="input-group">
  <input type="text" class="form-control" name="numero_cjs" placeholder="Datos a buscar" size="50" maxlength="50" required>
  </div>
  </div>
  <div class="form-group">
  <b> <button name="buscar" class="btn btn-info pull-left" type="submit">Búsqueda Socio</button> </b>
  </div>
</form>
</div>
</div>
</div>
</div>

<?php 
 if (isset($_POST["buscar"])) 
 {
      $busqueda = remove_junk($db->escape($_REQUEST['numero_cjs']));
      $productosPorPagina = 30;
      
      $query = "SELECT distinct * 
      FROM socios
      where
            soc_id = '$busqueda' or
            soc_nombre like '%$busqueda%' or soc_cedula like '%$busqueda%' or soc_celular like '%$busqueda%' LIMIT $productosPorPagina ;";
      $resultado = $db->query($query);
  }
?>
  <div class="col-xs-12">
  <table class="table table-bordered">
    <thead>
    <tr>
        <th>Código</th>
        <th>Nombre</th>
        <th>Teléfono</th>
    </tr>
    </thead>
    <tbody>
    <?php while($row = $resultado->fetch_assoc()) { ?>
    <tr>
        <td WIDTH="50"><a href=/sistema/pagosocioimprimir.php?EQP_ID="<?php echo $row['soc_id']; ?>"><?php echo $row['soc_id'] ?></a></td></td>
        <td WIDTH="50"><?php echo $row['soc_nombre'] ?></td>
        <td WIDTH="100"><?php echo $row['soc_celular']; ?></td>
    </tr>
 <?php } ?>
     </tbody>
     </table>
      </div>
      <?php include_once('layouts/footer.php'); ?>