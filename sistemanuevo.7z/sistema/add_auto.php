<?php
  $page_title = 'Agregar Unidad';
  require_once('includes/load.php');
  page_require_level(1);
  $groups = find_all('autos');
   $groups1 = find_all_order('socios');
?>
<?php
  if(isset($_POST['add_socio'])){

   //$req_fields = array('level','placa','numero','permiso');
   //validate_fields($req_fields);

   if(empty($errors)){
       $socio   = strtoupper(remove_junk($db->escape($_POST['level'])));
       $placa   = strtoupper(remove_junk($db->escape($_POST['placa'])));
       $numero   = strtoupper(remove_junk($db->escape($_POST['numero'])));
       $permiso   = strtoupper(remove_junk($db->escape($_POST['permiso'])));

        $query = "INSERT INTO autos (";
        $query .="soc_id, aut_placa, aut_numero, aut_permiso";
        $query .=") VALUES (";
        $query .="'{$socio}', '{$placa}', '{$numero}', '{$permiso}')";

       if($db->query($query)){
          //sucess
          $session->msg('s'," La unidad se ha creado satisfactoriamente");
          redirect('add_auto.php', false);
        } else {
          //failed
          $session->msg('d',' No se pudo crear la unidad.');
          redirect('add_auto.php', false);
        }
   } else {
     $session->msg("d", $errors);
      redirect('add_auto.php',false);
   }
 }
?>
<?php include_once('layouts/header.php'); ?>
  <?php echo display_msg($msg); ?>
  <div class="row">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Agregar Unidad</span>
       </strong>
      </div>
      <div class="panel-body">
        <div class="col-md-6">
          <form method="post" action="add_auto.php">
            
            <div class="form-group">
              <label for="level">Socio</label>
                <select class="form-control" name="level">
                  <?php foreach ($groups1 as $group ):?>
                   <option value="<?php echo $group['soc_id'];?>"><?php echo ucwords($group['soc_nombre']);?></option>
                <?php endforeach;?>
                </select>
            </div>
            <div class="form-group">
                <label for="placa">Placa</label>
                <input type="text" class="form-control" name="placa" placeholder="Placa de la unidad">
            </div>
            <div class="form-group">
                <label for="numero">Número</label>
                <input type="text" class="form-control" name ="numero"  placeholder="Número">
            </div>
            <div class="form-group">
                <label for="permiso">Permiso</label>
                <input type="text" class="form-control" name ="permiso"  placeholder="Permiso">
            </div>

            <div class="form-group clearfix">
              <button type="submit" name="add_socio" class="btn btn-primary">Guardar Unidad</button>
            </div>
        </form>
        </div>

      </div>

    </div>
  </div>

<?php include_once('layouts/footer.php'); ?>
