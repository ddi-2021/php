<?php
error_reporting(0);
  $page_title = 'Editar Socio';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(1);
   $groups = find_all_order('socios');
?>
<?php
  $e_user = find_by_idauto('autos',(int)$_GET['id']);
  $soc_id = (int)$_GET['id'];
  foreach($e_user as $a_user) {
        $aut_id = $e_user['aut_id'];
        $soc_id = $e_user['soc_id'];
        $aut_placa = $e_user['aut_placa'];
        $aut_numero = $e_user['aut_numero'];
        $aut_permiso   = $e_user['aut_permiso'];
  }  
?>

<?php
//Update User basic info
  if(isset($_POST['update'])) {
    $req_fields = array('soc_id','aut_placa','aut_numero','aut_permiso');
    validate_fields($req_fields);
    if(empty($errors)){
         //$soc_id = (int)$_GET['id'];
        $soc_id = strtoupper(remove_junk($db->escape($_POST['soc_id'])));
        $aut_placa = strtoupper(remove_junk($db->escape($_POST['aut_placa'])));
        $aut_numero = strtoupper(remove_junk($db->escape($_POST['aut_numero'])));
        $aut_permiso = strtoupper(remove_junk($db->escape($_POST['aut_permiso'])));

        $sql = "UPDATE autos SET soc_id ='{$soc_id}', aut_placa ='{$aut_placa}', aut_numero ='{$aut_numero}', aut_permiso='{$aut_permiso}'  WHERE aut_id='{$aut_id}'";

        $result = $db->query($sql);
          if($result && $db->affected_rows() === 1){
            $session->msg('s',"Unidad Actualizado ");
            redirect('autos.php?id='.(int)$e_user['id'], false);
          } else {
            $session->msg('d',' Lo siento no se actualizó los datos.');
            redirect('edit_autos.php?id='.(int)$e_user['id'], false);
          }
    } else {
      $session->msg("d", $errors);
      redirect('edit_autos.php?id='.(int)$e_user['id'],false);
    }
  }
?>

<?php include_once('layouts/header.php'); ?>
         <form method="post" action="edit_autos.php?id= <?php echo $aut_id;?> " class="clearfix">

 <div class="row">
   <div class="col-md-12"> <?php echo display_msg($msg); ?> </div>
  <div class="col-md-6">
     <div class="panel panel-default">
       <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          Actualiza Unidad : <?php echo $aut_id; ?> 
        </strong>
       </div>
       <div class="panel-body">
        
            <div class="form-group">
              <label for="level">Socio</label>
                <select class="form-control" name="soc_id">
                  <?php foreach ($groups as $group ):?>
                   <option value="<?php echo $group['soc_id'];?>"><?php echo ucwords($group['soc_nombre']);?></option>
                <?php endforeach;?>
                </select>
            </div>
           
            <div class="form-group">
            <label for="aut_placa" class="control-label">Placa</label>
            <input type="text" class="form-control" name="aut_placa" value="<?php echo $aut_placa; ?>">
            </div>
           
            <div class="form-group">
            <label for="aut_numero" class="control-label">Número</label>
            <input type="text" class="form-control" name="aut_numero" value="<?php echo $aut_numero; ?>">
            </div>

            <div class="form-group">
            <label for="aut_permiso" class="control-label">Permiso</label>
            <input type="text" class="form-control" name="aut_permiso" value="<?php echo $aut_permiso; ?>">
            </div>

            <div class="form-group">
                    <button type="submit" name="update" class="btn btn-info">Actualizar Socio</button>
            </div>
        </form>
       

       </div>
     </div>
  </div>

 </div>
<?php include_once('layouts/footer.php'); ?>
