<?php
error_reporting(0);
$page_title = 'Agregar ïtem STET';
require_once('includes/load.php');
page_require_level(3);
include_once('layouts/header.php');
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="awesomplete.base.css">
        <link rel="stylesheet" href="awesomplete.theme.css">
    </head>
       <title>Agregar ítems</title>
    </head>
<body>
    <div class="panel panel-default">
        <div class="panel-heading clearfix">
            <strong>
                <span class="glyphicon glyphicon-th"></span>
                <span>AGREGAR ITEMS</span>
            </strong>
        </div>
    </div>

    <form method="post" action="grabarcopletar.php">
        <table class="default"  border=0>
            <tr>
                <td> 
                    <b>Equipo Tipo<font title="Texto flotante" size=4 style="color:#FF0000">** </font></b>
                    <br>
                    <input type="text" class="form-control" id="EQP_TIPO" title="Tipo Equipo" name="EQP_TIPO" autocomplete="off" placeholder="Eq. Tipo"  size="20" maxlength="50" value="<?php echo $EQP_TIPO; ?>"  required  />   
                    <script src="awesomplete.min.js"></script>
                    <script src="script.js"></script>
                </td>
                <td>
                    <b>Equipo Marca<font size=4 style="color:#FF0000">** </font></b>
                    <input type="text" class="form-control" id="EQP_MARCA" name="EQP_MARCA"  placeholder="Marca" size="20" maxlength="50" value="<?php echo $EQP_MARCA; ?>"   required />   
                </td>  
                <td>    
                    <b>Equipo Modelo<font size=4 style="color:#FF0000">** </font></b>
                    <input type="text" class="form-control" id="EQP_MODELO"  name="EQP_MODELO"  placeholder="Modelo" size="20" maxlength="50" value="<?php echo $EQP_MODELO; ?>"  required  />   
                </td>

                <td>
                    <b>Equipo Serie<font size=4 style="color:#FF0000">** </font></b>
                    <input type="text" class="form-control" id="EQP_SERIE" name="EQP_SERIE"  placeholder="Serie" size="20" maxlength="20" value="<?php echo $EQP_SERIE; ?>"  required  />   
                </td>  

                <td>
                    <b>Código Actual<font size=4 style="color:#FF0000">** </font></b>
                    <input type="text" class="form-control" id="EQP_CODIGO_ACTUAL" name="EQP_CODIGO_ACTUAL"  placeholder="Cod. Actual" size="20" maxlength="20" value="<?php echo $EQP_CODIGO_ACTUAL; ?>"  required  />   
                </td>

                <td>
                    <b>Código Anterior<font size=4 style="color:#FF0000">** </font></b>
                    <input type="text" class="form-control" id="EQP_CODIGO_ANTERIOR"  name="EQP_CODIGO_ANTERIOR"  placeholder="Cod. Anterior" size="20" maxlength="20" value="<?php echo $EQP_CODIGO_ANTERIOR; ?>"  required  />   
                </td>
            </tr>
        </table>
        <table class="default" border="0">
            <tr>
                <td>
                    <b>Fecha Compra</b>
                    <input type="date" class="form-control" id="EQP_FECHA_COMPRA" name="EQP_FECHA_COMPRA"  placeholder="Fecha Compra" size="10" maxlength="10" value="<?php echo $EQP_FECHA_COMPRA; ?>"    />   
                </td>  


                <td>
                    <b>Eq. Periodo de Garantìa</b>
                    <input type="text" class="form-control" id="EQP_PERIODO_DE_GARANTIA" name="EQP_PERIODO_DE_GARANTIA"  placeholder="Per. Garantìa" size="10" maxlength="10" value="<?php echo $EQP_PERIODO_DE_GARANTIA; ?>"    />   
                </td>  

                <td>
                    <b>Eq. Proveedor</b>
                    <input type="text" class="form-control" id="EQP_PROVEEDOR"  name="EQP_PROVEEDOR"  placeholder="Eq. Proveedor" size="20" maxlength="20" value="<?php echo $EQP_PROVEEDOR; ?>"    />   
                </td>  

                <td>
                    <b>Eq. Categorìa<font size=4 style="color:#FF0000">** </font></b>
                        <select class="form-control" name="EQP_CATEGORIA_1" id="EQP_CATEGORIA_1" required >
                        <option value="">Categoria</option>
                        <option value="G.ESPECIAL">G.ESPECIAL</option>
                        <option value="G.CORRIENTE">G.CORRIENTE</option>
                </td> 

                <td>
                    <b>Eq. Data 1</b>
                    <input type="text" class="form-control" id="EQP_DATA_1" name="EQP_DATA_1"  placeholder="Eq. Data 1" size="20" maxlength="20" value="<?php echo $EQP_DATA_1; ?>"    />   
                </td>  

                <td>
                    <b>Inv. Año<font size=4 style="color:#FF0000">** </font></b>
                    <input type="text" class="form-control" id="INV_ANIO" name="INV_ANIO"  placeholder="Inv. Año" size="4" maxlength="4" value="<?php echo $INV_ANIO; ?>"  required  />   
                </td>  
            </tr>
        </table>        
        <table class="default" border="0">
            <tr>
                <td>
                    <b>Inv. Proceso Est.<font size=4 style="color:#FF0000">** </font></b>
                    <select class="form-control" name="INV_PROCESO_ESTADO" id="INV_PROCESO_ESTADO" required >
                    <option value="">Estado</option>
                    <option value="POR VALIDAR">POR VALIDAR</option>
                    <option value="VALIDADO">VALIDADO</option>
                </td>  

                <td> 
                    <b>Inv Código Otro<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_CODIGO_OTRO" name="INV_CODIGO_OTRO"  placeholder="Inv Còdigo Otro" size="15" maxlength="15" value="<?php echo $INV_CODIGO_OTRO; ?>"  required  />   
                </td>

                <td> 
                    <b>Subdirección<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_SUBDIRECCION" name="INV_SUBDIRECCION"  placeholder="Subdirecciòn" size="60" maxlength="150" value="<?php echo $INV_SUBDIRECCION; ?>" required   />   
                </td>

                <td> 
                    <b>Dirección<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_DIRECCION" name="INV_DIRECCION"  placeholder="Direcciòn" size="60" maxlength="150" value="<?php echo $INV_DIRECCION; ?>" required   />   
                </td>
            </tr>
        </table>

        <table class="default" border="0">
            <tr>
                <td> 
                    <b>Nombres<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_USUARIO_NOMBRES" name="INV_USUARIO_NOMBRES"  placeholder="Nombres" size="60" maxlength="60" value="<?php echo $INV_USUARIO_NOMBRES; ?>" required   />   
                </td>

                <td> 
                    <b>Directorio Activo<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_DIRECTORIO_ACTIVO" name="INV_DIRECTORIO_ACTIVO"  placeholder="Directorio Activo" size="50" maxlength="50" value="<?php echo $INV_DIRECTORIO_ACTIVO; ?>"  required  />   
                </td>
            </tr> 
        </table>
        <table>
            <tr>
                <td> 
                    <b>Correo Electrónico<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_CORREO_CIES" name="INV_CORREO_CIES"  placeholder="Correo Electrònico" size="60" maxlength="100" value="<?php echo $INV_CORREO_CIES; ?>"  required  />   
                </td>

                <td>  
                    <b>Extensión<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_NRO_EXTENSION" name="INV_NRO_EXTENSION"  placeholder="Exten" size="4" maxlength="4" value="<?php echo $INV_NRO_EXTENSION; ?>"  required  />   
                </td>

                <td>  
                    <b>Tlf. IP<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_TELEFONO_IP" name="INV_TELEFONO_IP"  placeholder="Tlf. IP" size="20" maxlength="20" value="<?php echo $INV_TELEFONO_IP; ?>" required   />   
                </td>
            </tr>
        </table>
        <table>
            <tr>
                <td>  
                    <b>Inv. Eq. Nombre<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_EQP_NOMBRE" name="INV_EQP_NOMBRE"  placeholder="Inv. Eq. Nombre" size="20" maxlength="20" value="<?php echo $INV_EQP_NOMBRE; ?>" required   />   
                </td>

                <td>  
                    <b>Eq. Ip. Lan<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_EQP_IP_LAN" name="INV_EQP_IP_LAN"  placeholder="Eq. Ip. Lan" size="20" maxlength="20" value="<?php echo $INV_EQP_IP_LAN; ?>"  required  />   
                </td>

                <td>  
                    <b>Eq. Mac Ethernet<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_EQP_MAC_ETH1" name="INV_EQP_MAC_ETH1"  placeholder="Eq. Mac Ethernet" size="60" maxlength="60" value="<?php echo $INV_EQP_MAC_ETH1; ?>"  required  />   
                </td>
            </TR>
        </table>

        <table>
            <tr>
                <td>  
                    <b>IP Wifi<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_EQP_IP_WIFI" name="INV_EQP_IP_WIFI"  placeholder="Ip. Wifi" size="20" maxlength="20" value="<?php echo $INV_EQP_IP_WIFI; ?>" required   />   
                </td>

                <td>  
                    <b>Eq. Mac Wifi<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_EQP_MAC_WIFI" name="INV_EQP_MAC_WIFI"  placeholder="Eq. Mac Wifi" size="60" maxlength="60" value="<?php echo $INV_EQP_MAC_WIFI; ?>"  required  />   
                </td>

                <td>  
                    <b>Punto Red<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_PUNTO_RED" name="INV_PUNTO_RED"  placeholder="Punto Red" size="40" maxlength="40" value="<?php echo $INV_PUNTO_RED; ?>" required   />   
                </td>
            </TR>
        </table>

        <table>
            <tr>
                <td>  
                    <b>Eq. Estado<font size=4 style="color:#FF0000">** </font></b>   
                    <select class="form-control" name="INV_EQP_ESTADO" id="INV_EQP_ESTADO" required >
                    <option value="">Eqp. Estado</option>
                    <option value="BUENO">BUENO</option>
                    <option value="MALO">MALO</option>
                    <option value="REGULAR">REGULAR</option>
                </td>

                <td>  
                    <b>Eq. Daño<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_EQP_DANIO_TIPO" name="INV_EQP_DANIO_TIPO"  placeholder="Eq. Daño" size="60" maxlength="100" value="<?php echo $INV_EQP_DANIO_TIPO; ?>"  required  />   
                </td>

                <td>  
                    <b>Manten. Fecha 01</b>   
                    <input type="date" class="form-control" id="INV_MANTENIMIENTO_FECHA_01" name="INV_MANTENIMIENTO_FECHA_01"  placeholder="Mantenimiento Fecha" size="15" maxlength="15" value="<?php echo $INV_MANTENIMIENTO_FECHA_01; ?>"  />   
                </td>

                <td>  
                    <b>Manten. Fecha 02</b>   
                    <input type="date" class="form-control" id="INV_MANTENIMIENTO_FECHA_02" name="INV_MANTENIMIENTO_FECHA_02"  placeholder="Mantenimiento Fecha" size="15" maxlength="15" value="<?php echo $INV_MANTENIMIENTO_FECHA_02; ?>"    />   
                </td>
            </TR>
        </table>

        <table>
            <tr>
                <td>  
                    <b>Inventario Observaciòn<font size=4 style="color:#FF0000">** </font></b>   
                    <input type="text" class="form-control" id="INV_OBSERVACION" name="INV_OBSERVACION"  placeholder="Inv. Observaciòn" size="60" maxlength="150" value="<?php echo $INV_OBSERVACION; ?>"  required  />   
                </td>

                <td>  
                    <b>Foto 1</b>   
                    <input type="text" class="form-control" id="INV_FOTO_01" name="INV_FOTO_01"  placeholder=" CODIGO_1.JPG" size="30" maxlength="30" value="<?php echo $INV_FOTO_01; ?>"    />   
                </td>

                <td>  
                    <b>Foto 2</b>   
                    <input type="text" class="form-control" id="INV_FOTO_02" name="INV_FOTO_02"  placeholder=" CODIGO_2.JPG" size="30" maxlength="30" value="<?php echo $INV_FOTO_02; ?>"    />   
                </td>

                <td>  
                    <b>Foto 3</b>   
                    <input type="text" class="form-control" id="INV_FOTO_03" name="INV_FOTO_03"  placeholder=" CODIGO_3.JPG" size="30" maxlength="30" value="<?php echo $INV_FOTO_03; ?>"    />   
                </td>
            </TR>
        </table>
<table>
<tr>
  <td>  
  <b>Inventario Realizado Por <font size=4 style="color:#555555">**</b>   
      <input style="color:#FF0000" type="text" class="form-control" id="INV_REALIZADO_POR" name="INV_REALIZADO_POR"  placeholder="** Inv. Realizado Por" size="50" maxlength="50" value="<?php echo $usuario_nob; ?>" readonly   />   
  </td>

  <td>  
  <b>Eq. Subestado<font size=4 style="color:#FF0000">** </font></b>   
    <select class="form-control" name="INV_DATA_1" id="INV_DATA_1" required >
    <option value="">Eqp. Subestado</option>
    <option value="EN USO">EN USO</option>
    <option value="SIN USO">SIN USO</option>
    <option value="OBSOLETO">OBSOLETO</option>
    <option value="INSERVIBLE">INSERVIBLE</option>
  </td>

  <td>  
  <b>Inventario Data 2</b>   
      <input type="text" class="form-control" id="INV_DATA_2" name="INV_DATA_2"  placeholder="Data 2" size="20" maxlength="20" value="<?php echo $INV_DATA_2; ?>"    />   
  </td>
  </TR>
</table>
        <button name="guardar" class="btn btn-info pull-Left" type="submit">Guardar nuevo ítem</button>
    </form>
</body>
</html>
