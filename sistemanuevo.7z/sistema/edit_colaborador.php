<?php
error_reporting(0);
  $page_title = 'Editar Colaborador';
  require_once('includes/load.php');
   page_require_level(1);
   $groups1 = find_all_colab('colaboradores');
?>
<?php
  $e_user = find_by_idcolaborador('colaboradores',(int)$_GET['id']);
  $soc_id = (int)$_GET['id'];
  foreach($e_user as $a_user) {
        $col_id = $e_user['col_id'];
        $nombre = $e_user['col_nombre'];
        $cedula = $e_user['col_cedula'];
        $direccion = $e_user['col_direccion1'];
        $celular = $e_user['col_celular'];
        $telefono   = $e_user['col_telefono'];
        $direccion2 = $e_user['col_direccion2'];
        $ubicacion = $e_user['col_ubicacion'];
        $referencia   = $e_user['col_referencia'];
  }  
?>

<?php
//Update User basic info
  if(isset($_POST['update'])) {
    //$req_fields = array('nombre',  'cedula', 'direccion','celular','telefono','direccion2','ubicacion','referencia');
    //validate_fields($req_fields);
    if(empty($errors)){
         $col_id = (int)$_GET['id'];
        $nombre = strtoupper(remove_junk($db->escape($_POST['nombre'])));
        $cedula = strtoupper(remove_junk($db->escape($_POST['cedula'])));
        $direccion = strtoupper(remove_junk($db->escape($_POST['direccion'])));
        $celular = strtoupper(remove_junk($db->escape($_POST['celular'])));
        $telefono   = strtoupper(remove_junk($db->escape($_POST['telefono'])));
        $direccion2 = strtoupper(remove_junk($db->escape($_POST['direccion2'])));
        $ubicacion = strtoupper(remove_junk($db->escape($_POST['ubicacion'])));
        $referencia   = strtoupper(remove_junk($db->escape($_POST['referencia'])));

        $sql = "UPDATE colaboradores SET col_nombre ='{$nombre}', col_cedula ='{$cedula}', col_direccion1 ='{$direccion}', col_celular='{$celular}', col_telefono='{$telefono}', col_direccion2='{$direccion2}', col_ubicacion='{$ubicacion}', col_referencia='{$referencia}' WHERE col_id='{$col_id}'";
          $result = $db->query($sql);
          if($result && $db->affected_rows() === 1){
            $session->msg('s',"Colaborador Actualizado ");
            redirect('colaboradores.php?id='.(int)$e_user['id'], false);
          } else {
            $session->msg('d',' Lo siento no se actualizó los datos.');
            redirect('edit_colaborador.php?id='.(int)$e_user['id'], false);
          }
    } else {
      $session->msg("d", $errors);
      redirect('edit_colaborador.php?id='.(int)$e_user['id'],false);
    }
  }
?>

<?php include_once('layouts/header.php'); ?>
         <form method="post" action="edit_colaborador.php?id= <?php echo $soc_id;?> " class="clearfix">

 <div class="row">
   <div class="col-md-12"> <?php echo display_msg($msg); ?> </div>
  <div class="col-md-6">
     <div class="panel panel-default">
       <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          Actualiza Colaborador : <?php echo $col_id; ?> 
        </strong>
       </div>
       <div class="panel-body">
        
            <div class="form-group">
            <label for="nombre" class="control-label">Nombres</label>
            <input type="text" class="form-control" name="nombre" value="<?php echo $nombre; ?>">
            </div>

            <div class="form-group">
            <label for="cedula" class="control-label">Cédula</label>
            <input type="text" class="form-control" name="cedula" value="<?php echo $cedula; ?>">
            </div>
           
            <div class="form-group">
            <label for="direccion" class="control-label">Dirección</label>
            <input type="text" class="form-control" name="direccion" value="<?php echo $direccion; ?>">
            </div>
           
            <div class="form-group">
            <label for="celular" class="control-label">Celular</label>
            <input type="text" class="form-control" name="celular" value="<?php echo $celular; ?>">
            </div>

            <div class="form-group">
            <label for="telefono" class="control-label">Teléfono</label>
            <input type="text" class="form-control" name="telefono" value="<?php echo $telefono; ?>">
            </div>

            <div class="form-group">
            <label for="direccion2" class="control-label">Dirección 2</label>
            <input type="text" class="form-control" name="direccion2" value="<?php echo $direccion2; ?>">
            </div>

            <div class="form-group">
            <label for="ubicacion" class="control-label">Ubicación</label>
            <input type="text" class="form-control" name="ubicacion" value="<?php echo $ubicacion; ?>">
            </div>

            <div class="form-group">
            <label for="referencia" class="control-label">Referencia</label>
            <input type="text" class="form-control" name="referencia" value="<?php echo $referencia; ?>">
            </div>

            <div class="form-group">
                    <button type="submit" name="update" class="btn btn-info">Actualizar Colaborador</button>
            </div>
        </form>
       

       </div>
     </div>
  </div>

 </div>
<?php include_once('layouts/footer.php'); ?>
