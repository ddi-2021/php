<?php
$page_title = 'Cobros';
require_once('includes/load.php');
require 'conexion.php';
// Checkin What level user has permission to view this page
page_require_level(3);
include_once('layouts/header.php');
$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
    $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
?>
<div class="row">
    <div class="col-md-10">
        <div class="panel">
            <div class="panel-body">
                <div class="form-group">
                    <div class="panel panel-default">
                        <div class="panel-heading clearfix">
                            <strong>
                                <span class="glyphicon glyphicon-th"></span>
                                <span>VALORES A PAGAR POR SOCIO</span>
                            </strong>
                        </div>
                    </div>
                </div>

                <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                <html xmlns="http://www.w3.org/1999/xhtml">
                    <head>
                        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                        <script type="text/javascript" src="js/validacion.js"></script>
                        <script type="text/javascript" src="select_dependientes.js"></script>
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <meta http-equiv="X-UA-Compatible" content="ie=edge">
                                <link rel="stylesheet" href="awesomplete.base.css">
                                    <link rel="stylesheet" href="awesomplete.theme.css">
                                        <div class="col-xs-12">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Socio</th>
                                                        <th>Nombre</th>
                                                        <th>Valor total de cta</th>
                                                        <th>Saldo a Pagar</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <form method="post" action="pagarsql.php">

                                                        <?php
                                                        if (isset($_REQUEST["EQP_ID"])) {
                                                            $ID = $_REQUEST["EQP_ID"];
                                                        }
                                                        $contador = 1;
                                                        $query = "SELECT * FROM asignar_cobros a, cobros c, socios s
where 
a.cob_id = c.cob_id and
a.soc_id = s.soc_id and
a.asg_estado = 1 and
a.soc_id = " . $ID;
                                                        $resultado = $mysqli->query($query);
                                                        ?>
                                                        <?php while ($row = $resultado->fetch_assoc()) { ?>
                                                            <tr>
                                                                <td WIDTH="50"><?php echo $row['soc_nombre'] ?></td>
                                                                <td WIDTH="50"><a href=pagar.php?EQP_ID="<?php echo $row['asg_id']; ?>"><?php echo $row['cob_nombre'] ?></a></td></td>
                                                               <td WIDTH="100"><?php echo $row['asg_total']; ?></td>
                                                                <td WIDTH="100"><?php echo $row['asg_saldo']; ?></td>
                                                            </tr>
                                                        <?php } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        </form>

                                        <?php include_once('layouts/footer.php'); ?>
