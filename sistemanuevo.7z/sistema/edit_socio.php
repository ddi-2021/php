<?php
error_reporting(0);
  $page_title = 'Editar Socio';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(1);
   $groups1 = find_all_order('socios');
?>
<?php
  $e_user = find_by_idsocios('socios',(int)$_GET['id']);
  $soc_id = (int)$_GET['id'];
  foreach($e_user as $a_user) {
        $soc_id = $e_user['soc_id'];
        $nombre = $e_user['soc_nombre'];
        $direccion = $e_user['soc_direccion1'];
        $celular = $e_user['soc_celular'];
        $telefono   = $e_user['soc_telefono'];
        $direccion2 = $e_user['soc_direccion2'];
        $ubicacion = $e_user['soc_ubicacion'];
        $referencia   = $e_user['soc_referencia'];
  }  
?>

<?php
//Update User basic info
  if(isset($_POST['update'])) {
    $req_fields = array('nombre','direccion','celular','telefono','direccion2','ubicacion','referencia');
    validate_fields($req_fields);
    if(empty($errors)){
         $soc_id = (int)$_GET['id'];
        $nombre = strtoupper(remove_junk($db->escape($_POST['nombre'])));
        $direccion = strtoupper(remove_junk($db->escape($_POST['direccion'])));
        $celular = strtoupper(remove_junk($db->escape($_POST['celular'])));
        $telefono   = strtoupper(remove_junk($db->escape($_POST['telefono'])));
        $direccion2 = strtoupper(remove_junk($db->escape($_POST['direccion2'])));
        $ubicacion = strtoupper(remove_junk($db->escape($_POST['ubicacion'])));
        $referencia   = strtoupper(remove_junk($db->escape($_POST['referencia'])));

        $sql = "UPDATE socios SET soc_nombre ='{$nombre}', soc_direccion1 ='{$direccion}', soc_celular='{$celular}', soc_telefono='{$telefono}', soc_direccion2='{$direccion2}', soc_ubicacion='{$ubicacion}', soc_referencia='{$referencia}' WHERE soc_id='{$soc_id}'";

        $result = $db->query($sql);
          if($result && $db->affected_rows() === 1){
            $session->msg('s',"Socio Actualizado ");
            redirect('socios.php?id='.(int)$e_user['id'], false);
          } else {
            $session->msg('d',' Lo siento no se actualizó los datos.');
            redirect('edit_socio.php?id='.(int)$e_user['id'], false);
          }
    } else {
      $session->msg("d", $errors);
      redirect('edit_socio.php?id='.(int)$e_user['id'],false);
    }
  }
?>

<?php include_once('layouts/header.php'); ?>
         <form method="post" action="edit_socio.php?id= <?php echo $soc_id;?> " class="clearfix">

 <div class="row">
   <div class="col-md-12"> <?php echo display_msg($msg); ?> </div>
  <div class="col-md-6">
     <div class="panel panel-default">
       <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          Actualiza Socio : <?php echo $soc_id; ?> 
        </strong>
       </div>
       <div class="panel-body">
        
            <div class="form-group">
            <label for="nombre" class="control-label">Nombres</label>
            <input type="text" class="form-control" name="nombre" value="<?php echo $nombre; ?>">
            </div>
           
            <div class="form-group">
            <label for="direccion" class="control-label">Dirección</label>
            <input type="text" class="form-control" name="direccion" value="<?php echo $direccion; ?>">
            </div>
           
            <div class="form-group">
            <label for="celular" class="control-label">Celular</label>
            <input type="text" class="form-control" name="celular" value="<?php echo $celular; ?>">
            </div>

            <div class="form-group">
            <label for="telefono" class="control-label">Teléfono</label>
            <input type="text" class="form-control" name="telefono" value="<?php echo $telefono; ?>">
            </div>

            <div class="form-group">
            <label for="direccion2" class="control-label">Dirección 2</label>
            <input type="text" class="form-control" name="direccion2" value="<?php echo $direccion2; ?>">
            </div>

            <div class="form-group">
            <label for="ubicacion" class="control-label">Ubicación</label>
            <input type="text" class="form-control" name="ubicacion" value="<?php echo $ubicacion; ?>">
            </div>

            <div class="form-group">
            <label for="referencia" class="control-label">Referencia</label>
            <input type="text" class="form-control" name="referencia" value="<?php echo $referencia; ?>">
            </div>

            <div class="form-group">
                    <button type="submit" name="update" class="btn btn-info">Actualizar Socio</button>
            </div>
        </form>
       

       </div>
     </div>
  </div>

 </div>
<?php include_once('layouts/footer.php'); ?>
