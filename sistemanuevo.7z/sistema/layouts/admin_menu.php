<ul>
  <li>
    <a href="admin.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Panel de control</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Accesos</span>
    </a>
    <ul class="nav submenu">
      <li><a href="group.php">Administrar grupos</a> </li>
      <li><a href="users.php">Administrar usuarios</a> </li>
   </ul>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Administración</span>
    </a>
    <ul class="nav submenu">
        <li><a href="cobrosadm.php">Administrar Cobros</a> </li>
        <li><a href="pagosadm.php">Administrar Pagos</a> </li>
       <li><a href="busqueda_cont.php">Cobros</a> </li>
       <li><a href="pagos.php">Pagos</a> </li>
   </ul>
  </li>


  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Socios</span>
    </a>
    <ul class="nav submenu">
       <li><a href="socios.php">Administrar Socios</a> </li>
       <li><a href="colaboradores.php">Administrar Colaboradores</a> </li>
       <li><a href="autos.php">Administrar Autos</a> </li>
   </ul>
  </li>
  
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-signal"></i>
       <span>Reporte Coop.</span>
      </a>
      <ul class="nav submenu">
        <li><a href="reportesocios.php">Reporte de Socios </a></li>
        <li><a href="reporteunidades.php">Reporte de Unidades </a></li>
        <li><a href="reportecobros.php">Reporte Deuda Socio</a></li>
        <li><a href="reportepagos.php">Reporte de Pagos</a> </li>
        <li><a href="impresionrecibos.php">Impresión de recibos</a> </li>
      </ul>
  </li>
</ul>
