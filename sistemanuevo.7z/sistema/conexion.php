<?php
	
	$mysqli = new mysqli('localhost', 'root', '', 'oswa_inv');
	
	if($mysqli->connect_error){
		
		die('Error en la conexion' . $mysqli->connect_error);
		
	}
?>