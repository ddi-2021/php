<?php
error_reporting(0);
$page_title = 'Bùsqueda Recibos';
require_once('includes/load.php');
page_require_level(3);
include_once('layouts/header.php');
?>
<div class="row">
<div class="col-md-6">
<div class="panel">
<div class="panel-body">
<form class="clearfix" method="post" action="">
  <div class="form-group">
  <div class="panel panel-default">
  <div class="panel-heading clearfix">
  <strong>
    <span class="glyphicon glyphicon-th"></span>
    <span>BÚSQUEDA POR RECIBO</span>
  </strong>
  </div>
  </div>
  <div class="input-group">
  <input type="text" class="form-control" name="numero_cjs" placeholder="Datos a buscar" size="50" maxlength="50" required>
  </div>
  </div>
  <div class="form-group">
  <b> <button name="buscar" class="btn btn-info pull-left" type="submit">Búsqueda Recibo</button> </b>
  </div>
</form>
</div>
</div>
</div>
</div>

<?php 
 if (isset($_POST["buscar"])) 
 {
      $busqueda = remove_junk($db->escape($_REQUEST['numero_cjs']));
      $productosPorPagina = 30;
      
      $query = "SELECT * FROM recibos r, asignar_cobros a, socios s
      where
        (r.asg_id = a.asg_id and a.soc_id = s.soc_id) and 
             r.rec_id = '$busqueda'  LIMIT $productosPorPagina ;";
      $resultado = $db->query($query);
  }
?>
  <div class="col-xs-12">
  <table class="table table-bordered">
    <thead>
    <tr>
        <th>Recibo</th>
        <th>Socio</th>
        <th>Valor</th>
    </tr>
    </thead>
    <tbody>
    <?php while($row = $resultado->fetch_assoc()) { ?>
    <tr>
        <td WIDTH="50"><a href=editardatos.php?EQP_ID="<?php echo $row['rec_id']; ?>"><?php echo $row['rec_id'] ?></a></td></td>
        <td WIDTH="50"><?php echo $row['soc_nombre'] ?></td>
        <td WIDTH="100"><?php echo $row['asg_valor']; ?></td>
    </tr>
 <?php } ?>
     </tbody>
     </table>
      </div>
      <?php include_once('layouts/footer.php'); ?>