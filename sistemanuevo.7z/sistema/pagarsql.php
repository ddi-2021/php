<?php
include 'conexion.php';
if (isset($_REQUEST["ID"])) {
    $ID = $_REQUEST["ID"];
}

echo "id ";
exit(0);

if (isset($_REQUEST["asg_id"])) {
$asg_id = $_REQUEST["asg_id"];
}

if (isset($_REQUEST["asg_valor"])) {
$asg_valor = $_REQUEST["asg_valor"];
}

if (isset($_REQUEST["asg_total"])) {
$asg_total = $_REQUEST["asg_total"];
}

if (isset($_REQUEST["asg_saldo"])) {
$asg_saldo = $_REQUEST["asg_saldo"];
}

echo "id ". $asg_id. " asg_valor ".$asg_valor. " asg_total ".$asg_total. " asg_saldo ".$asg_saldo;

exit(0);

$asg_saldo = $asg_valor - ($asg_saldo + $asg_total);


$update = "UPDATE asignar_cobros
        SET 
         asg_total = '$asg_total',
         asg_saldo = '$asg_valor',
        asg_estado = '$asg_estado'
        WHERE asg_id = $asg_id;";

$resulta_update = mysql_query($con, $query);
echo "< script type='text/javascript'>
    window.location='editardatos.php';
    </script>";

