<?php
try {
    require('fpdf/fpdf.php');
    $mysqli = new mysqli('localhost', 'root', '', 'oswa_inv');
    if ($mysqli->connect_errno) {
        echo "Failed to connect to MySQL: " . $mysqli->connect_error;
        exit();
    }

    $sql = "select * from socios s, autos a 
            where s.soc_id = a.soc_id
            order by soc_nombre";

    $result = $mysqli->query($sql);
    $datos = mysqli_fetch_all($result, MYSQLI_ASSOC);

    $pdf = new FPDF();
    $pdf->AddPage();

    $contador = 0;
    foreach ($datos as $item => $row) {

        if ($contador == 0) {
            $pdf->SetFont('Arial', 'B', 14);
            $pdf->Cell(40, 6, '', 0, 0, 'C');
            $pdf->Cell(120, 6, 'COOPERATIVA ILUSTRE JUAN MONTALVO', 1, 0, 'C');
            $pdf->Ln(10);
            $pdf->SetFillColor(232, 232, 232);
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->Cell(110, 6, 'Apellidos y Nombres', 1, 0, 'C', 1);
            $pdf->Cell(40, 6, utf8_decode('Unidad'), 1, 0, 'C', 1);
            $pdf->Cell(40, 6, utf8_decode('Número'), 1, 0, 'C', 1);
            $pdf->Ln(8);
            $pdf->SetFont('Arial', 'B', 8);
        }

        $soc_nombre = $row['soc_nombre'];
        $aut_placa = $row['aut_placa'];
        $aut_numero = $row['aut_numero'];
        
        $pdf->Cell(110, 8, $soc_nombre, 1, 0, 'L', 0);
        $pdf->Cell(40, 8, $aut_placa, 1, 0, 'L', 0);
        $pdf->Cell(40, 8, $aut_numero, 1, 0, 'L', 0);
        $pdf->Ln();

        ++$contador;
        if ($contador == 60) {
            $contador = 0;
        }
    }


    $pdf->Cell(40, 6, 'Total Socios : ' . $contador, 1, 0, 'C', 1);

    $pdf->Output();
    mysqli_close($mysqli);
} catch (Exception $e) {
    echo 'Error : ', $e->getMessage(), "\n";
}
?>
